import sys
from colorama import Fore, init
init(autoreset=True)

class Command:
    def execute(self):
        pass

class Cube:
    def __init__(self, size, color):
        self.size = size
        self.color = color

    def draw(self):
        colors = {
            'red': Fore.RED,
            'green': Fore.GREEN,
            'blue': Fore.BLUE,
            'yellow': Fore.YELLOW,
            'magenta': Fore.MAGENTA,
            'cyan': Fore.CYAN,
            'white': Fore.WHITE,
            'black': Fore.BLACK
        }
        cube_color = colors.get(self.color.lower(), Fore.WHITE)
        t = v = h = int(self.size / 2)
        s, p, b, f, n = " ", cube_color + "+", cube_color + "|", cube_color + "/", "\n"
        l = p + (cube_color + "-") * (t * 4) + p
        S = s * (4 * t)
        k = s * h
        K = b + S + b
        r = (s * t) + s + l + n
        while t:
            r += (s * t) + f + (S + f + s * (h - t) + b) + n
            t -= 1
        r += l + (k + b) + n + ((K + k + b + n) * (v - 1)) + K + k + p + n
        while v:
            v -= 1
            r += K + (s * v) + f + n
        r += l
        return r

class Square:
    def __init__(self, size, color):
        self.size = size
        self.color = color

    def draw(self):
        colors = {
            'red': Fore.RED,
            'green': Fore.GREEN,
            'blue': Fore.BLUE,
            'yellow': Fore.YELLOW,
            'magenta': Fore.MAGENTA,
            'cyan': Fore.CYAN,
            'white': Fore.WHITE,
            'black': Fore.BLACK
        }
        square_color = colors.get(self.color.lower(), Fore.WHITE)
        square = ""
        for i in range(self.size):
            square += square_color + "+" + "-" * self.size + "+" + "\n"
            for j in range(self.size - 2):
                square += square_color + "|" + " " * self.size + "|" + "\n"
            square += square_color + "+" + "-" * self.size + "+" + "\n"
        return square

class DrawCubeCommand(Command):
    def __init__(self, cube):
        self.cube = cube

    def execute(self):
        return self.cube.draw()

class DrawSquareCommand(Command):
    def __init__(self, square):
        self.square = square

    def execute(self):
        return self.square.draw()

class Scene:
    def __init__(self):
        self.shapes = []

    def add_shape(self, shape):
        self.shapes.append(shape)

    def render_scene(self):
        for shape in self.shapes:
            print(shape.draw())

class CommandLineInterface:
    def __init__(self):
        self.scene = Scene()

    def run(self):
        print("Welcome to the ASCII Art Generator!")
        while True:
            command = input("Enter a command (create/cube/square/size/resize/color/render/save/exit): ").lower()
            if command == "exit":
                sys.exit(0)
            elif command == "create":
                self.create_shape()
            elif command == "render":
                self.scene.render_scene()
            elif command == "size":
                self.set_size()
            elif command == "resize":
                self.resize_shape()
            elif command == "color":
                self.set_color()
            elif command == "save":
                self.save_to_file()
            else:
                print("Invalid command. Please try again.")

    def create_shape(self):
        shape_type = input("Enter shape type (cube/square): ").lower()
        size_input = input("Enter the size: ")
        try:
            size = int(size_input)
        except ValueError:
            print("Invalid input. Please enter a numeric size.")
            return
        color = input("Enter color (e.g., red, green, blue, yellow): ").lower()
        if shape_type == "cube":
            shape = Cube(size, color)
        elif shape_type == "square":
            shape = Square(size, color)
        else:
            print("Invalid shape type.")
            return
        self.scene.add_shape(shape)
        print(f"{shape_type.capitalize()} created.")

    def set_size(self):
        if not self.scene.shapes:
            print("No shape to set size. Please create a shape first.")
            return
        size = int(input("Enter the size for the current shape: "))
        current_shape = self.scene.shapes[-1]
        current_shape.size = size

    def resize_shape(self):
        if not self.scene.shapes:
            print("No shape to resize. Please create a shape first.")
            return
        scaling_factor = float(input("Enter the scaling factor: "))
        current_shape = self.scene.shapes[-1]
        current_shape.size = int(current_shape.size * scaling_factor)

    def set_color(self):
        if not self.scene.shapes:
            print("No shape to set color. Please create a shape first.")
            return
        color = input("Enter color (e.g., red, green, blue): ")
        current_shape = self.scene.shapes[-1]
        current_shape.color = color
        print(f"Color set to {color} for the current shape.")

    def save_to_file(self):
        if not self.scene.shapes:
            print("No shapes to save. Please create a shape first.")
            return
        file_name = input("Enter file name to save ASCII art (.txt): ")
        try:
            with open(file_name, "w") as file:
                for shape in self.scene.shapes:
                    file.write(shape.draw() + "\n\n")
            print(f"ASCII art saved to {file_name}.")
        except Exception as e:
            print(f"Error saving to file: {e}")

if __name__ == "__main__":
    cli = CommandLineInterface()
    cli.run()
