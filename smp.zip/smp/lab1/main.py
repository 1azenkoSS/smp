import appSet
import math


appSet.set_color()


final_res = 0
memory = 0
history = []


def get_operator():

    while True:
        operator = input("Введіть оператор (+, -, *, /, %, ^, корінь, MS, M+, MC): ")
        if operator in ["+", "-", "*", "/", "%", "^", "корінь", "MS", "MR", "M+", "MC"]:
            return operator
        else:
            print("Невірний оператор! Спробуйте ще раз.")


def get_number(prompt):

    while True:
        value = input(prompt)
        if value == "MR":
            return memory
        try:
            return float(value)
        except ValueError:
            print("Невірне число! Спробуйте ще раз.")


def get_numbers(operator):

    if operator == "корінь":
        num1 = get_number("Введіть число: ")
        return num1, None
    elif operator in ["MS", "M+", "MC"]:
        return None, None
    else:
        num1 = get_number("Введіть перше число: ")
        num2 = get_number("Введіть друге число: ")
        return num1, num2


def calculate(num1, num2, operator):

    global memory, final_res
    if operator == "+":
        return num1 + num2
    elif operator == "-":
        return num1 - num2
    elif operator == "*":
        return num1 * num2
    elif operator == "/":
        if num2 != 0:
            return num1 / num2
        else:
            print("Помилка: ділення на нуль!")
            return None
    elif operator == "%":
        return num1 % num2
    elif operator == "^":
        return num1 ** num2
    elif operator == "корінь":
        if num1 >= 0:
            return math.sqrt(num1)
        else:
            print("Помилка: корінь з від'ємного числа!")
            return None
    elif operator == "MS":  # Memory Store
        memory = final_res
        print(f"Число {final_res} збережено в пам'яті.")
    elif operator == "MR":
        print(f"Число з пам'яті: {memory}")
        return memory
    elif operator == "M+":
        memory += final_res
        print(f"До пам'яті додано: {final_res}. Нове значення пам'яті: {memory}")
    elif operator == "MC":
        memory = 0
        print("Пам'ять очищено.")


def main():
    global history, final_res
    while True:

        change_color = input("Бажаєте змінити колір консолі? (yes/no): ")
        if change_color.lower() == "yes":
            appSet.set_color()

        operator = get_operator()
        num1, num2 = get_numbers(operator)

        if operator not in ["MS", "MR", "M+", "MC"]:
            result = calculate(num1, num2, operator)
            final_res = result
            if result is not None:
                print(f"Результат: {result}")
                history.append(f"{num1} {operator} {num2} = {result}")
        else:
            calculate(num1, num2, operator)

        again = input("Бажаєте виконати ще одне обчислення? (yes/no/history): ")
        if again.lower() == "history":
            if history:
                print("Історія обчислень:")
                for entry in history:
                    print(entry)
            else:
                print("Історія обчислень порожня.")
        elif again.lower() != "yes":
            break

    print("Дякуємо за використання калькулятора!")


if __name__ == "__main__":
    main()