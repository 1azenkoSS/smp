import colorama
from colorama import Fore, Style


def set_color():

    print("Виберіть колір тексту:")
    print("1. Червоний")
    print("2. Зелений")
    print("3. Синій")
    print("4. Жовтий")
    print("5. За замовчуванням")

    choice = input("Введіть номер кольору: ")

    if choice == '1':
        print(Fore.RED + "Тепер текст червоний.")
    elif choice == '2':
        print(Fore.GREEN + "Тепер текст зелений.")
    elif choice == '3':
        print(Fore.BLUE + "Тепер текст синій.")
    elif choice == '4':
        print(Fore.YELLOW + "Тепер текст жовтий.")
    else:
        print(Style.RESET_ALL + "Колір скинуто на стандартний.")
