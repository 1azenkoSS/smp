from Presentation_Layer.classes.console import Console


if __name__ == "__main__":
    Console()